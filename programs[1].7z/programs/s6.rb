text="i am good"
puts text.index("a")
