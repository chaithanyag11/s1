str="chay"
str.concat("g","s")
puts str
