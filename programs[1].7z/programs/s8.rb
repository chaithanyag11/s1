puts 87.is_a? Integer
