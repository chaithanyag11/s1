puts"string".reverse
