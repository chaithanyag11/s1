p"   Hello  ".strip
