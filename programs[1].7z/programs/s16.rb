string = "abc123"

p string[0,3]
# "abc"


