
text="i am good"
puts text.gsub("o","g")

