p "HELLO N!".downcase
