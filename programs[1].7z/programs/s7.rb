
puts i="aples"<=>"apples"

