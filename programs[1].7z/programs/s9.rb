
a = 'scar'
b = 'cars'
puts a.chars.sort == b.chars.sort
