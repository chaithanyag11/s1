b="chaithanya"
puts b.sub("k","c")
