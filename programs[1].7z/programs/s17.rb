puts "Mangal".index(?g)
