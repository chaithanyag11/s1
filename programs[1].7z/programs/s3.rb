def left2(str)
   puts str[0]
end

left2('hello')
