p "abc".chars.permutation.map &:join
