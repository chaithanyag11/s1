puts "string".chars
p "a string".split("")
