p 'happy new year'.include?('ek')
