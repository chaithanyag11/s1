puts "hello n".upcase
