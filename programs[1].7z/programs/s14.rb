input = 'chaithanya'
 
input.each_char { |c| 
    puts c
}
